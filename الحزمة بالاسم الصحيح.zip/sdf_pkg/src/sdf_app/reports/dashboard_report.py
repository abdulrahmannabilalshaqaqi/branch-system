# -*- coding: utf-8 -*-
"""تقرير لوحة التحكم PDF: ملخص المؤشرات للطباعة والأرشفة."""
from datetime import datetime
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, Spacer, Table, TableStyle

from ..core.workflow import STATUS_NAMES
from .pdf_base import FormDocTemplate, ar, make_styles, money_ar, wrap_ar

NAVY = colors.HexColor("#1F3A5F")
LIGHT = colors.HexColor("#F2F4F7")
BORDER = colors.HexColor("#9AA3B2")
W = 182 * mm


def _tbl(data, col_widths, header=True):
    t = Table(data, colWidths=col_widths, repeatRows=1 if header else 0)
    cmds = [
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (0, 0), (-1, -1), "RIGHT"),
        ("GRID", (0, 0), (-1, -1), 0.6, BORDER),
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]
    if header:
        cmds.append(("BACKGROUND", (0, 0), (-1, 0), NAVY))
        cmds.append(("TEXTCOLOR", (0, 0), (-1, 0), colors.white))
    t.setStyle(TableStyle(cmds))
    return t


def build_dashboard_pdf(stats: dict, output_path: Path, settings: dict = None,
                        filter_label: str = "") -> Path:
    settings = settings or {}
    styles = make_styles()
    output_path = Path(output_path)
    doc = FormDocTemplate(str(output_path), print_date=datetime.now().strftime("%Y-%m-%d"))
    story = []
    story.append(Paragraph(ar(settings.get("org_name", "صندوق تنمية المهارات")), styles["title"]))
    story.append(Paragraph(ar(settings.get("office_name", "مكتب النائب لشؤون الفروع")),
                           styles["subtitle"]))
    story.append(Spacer(1, 2 * mm))
    story.append(Paragraph(ar("لوحة التحكم — ملخص المؤشرات"), styles["title"]))
    if filter_label:
        story.append(Paragraph(ar(f"الترشيح: {filter_label}"), styles["cell_bold"]))
    story.append(Spacer(1, 3 * mm))

    by = stats["by_status"]
    order = ["tech_review", "finance_review", "ready_disburse", "disbursed",
             "missing_docs", "returned", "rejected", "new", "received",
             "tech_done", "approved", "archived"]
    rows = [[Paragraph(ar("الحالة"), styles["cell_bold"]),
             Paragraph(ar("العدد"), styles["cell_bold"])]]
    for code in order:
        rows.append([Paragraph(ar(STATUS_NAMES.get(code, code)), styles["cell"]),
                     Paragraph(ar(f"{by.get(code, 0):,}"), styles["cell"])])
    rows.insert(1, [Paragraph(ar("إجمالي الملفات"), styles["cell_bold"]),
                    Paragraph(ar(f"{stats['total']:,}"), styles["cell_bold"])])
    story.append(_tbl(rows, [W - 40 * mm, 40 * mm]))
    story.append(Spacer(1, 3 * mm))

    sums = stats["sums"]
    fin = [[Paragraph(ar("البيان"), styles["cell_bold"]),
            Paragraph(ar("القيمة"), styles["cell_bold"])]]
    for label, val in [("إجمالي المبالغ المطالب بها", money_ar(sums["claimed"])),
                       ("إجمالي مبالغ التمويل", money_ar(sums["funding"])),
                       ("الفروقات (مطالب − تمويل)",
                        money_ar(sums["claimed"] - sums["funding"])),
                       ("عدد المتدربين (المعتمد)", f"{stats.get('trainees_total', 0):,}")]:
        fin.append([Paragraph(ar(label), styles["cell"]),
                    Paragraph(ar(val), styles["cell"])])
    story.append(_tbl(fin, [W - 60 * mm, 60 * mm]))
    story.append(Spacer(1, 3 * mm))

    for title, key in [("الملفات حسب الفرع", "by_branch"),
                       ("الملفات حسب المجال التدريبي", "by_field")]:
        story.append(Paragraph(ar(title), styles["cell_bold"]))
        data = [[Paragraph(ar("البيان"), styles["cell_bold"]),
                 Paragraph(ar("العدد"), styles["cell_bold"])]]
        for r in stats[key][:10]:
            data.append([Paragraph(ar(r["name"] or "غير محدد"), styles["cell"]),
                         Paragraph(ar(f"{r['c']:,}"), styles["cell"])])
        story.append(_tbl(data, [W - 40 * mm, 40 * mm]))
        story.append(Spacer(1, 3 * mm))

    story.append(Paragraph(ar("الملفات حسب شهر التنفيذ"), styles["cell_bold"]))
    data = [[Paragraph(ar("الشهر"), styles["cell_bold"]),
             Paragraph(ar("العدد"), styles["cell_bold"])]]
    for r in stats["by_month"]:
        data.append([Paragraph(ar(r["ym"]), styles["cell"]),
                     Paragraph(ar(f"{r['c']:,}"), styles["cell"])])
    story.append(_tbl(data, [W - 40 * mm, 40 * mm]))
    doc.build(story)
    return output_path
