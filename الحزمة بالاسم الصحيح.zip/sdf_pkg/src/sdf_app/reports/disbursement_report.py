# -*- coding: utf-8 -*-
"""كشف الصرف: قائمة الملفات المقرر صرفها للطباعة والتوثيق."""
from datetime import datetime
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, Spacer, Table, TableStyle

from ..core.finance import format_money
from .pdf_base import FormDocTemplate, ar, make_styles

NAVY = colors.HexColor("#1F3A5F")
BORDER = colors.HexColor("#9AA3B2")
W = 182 * mm


def build_disbursement_statement(rows: list, output_path, settings: dict = None) -> Path:
    settings = settings or {}
    styles = make_styles()
    output_path = Path(output_path)
    doc = FormDocTemplate(str(output_path), print_date=datetime.now().strftime("%Y-%m-%d"))
    story = []
    story.append(Paragraph(ar("الجمهورية اليمنية"), styles["subtitle"]))
    story.append(Paragraph(ar(settings.get("org_name", "صندوق تنمية المهارات")), styles["title"]))
    story.append(Paragraph(ar(settings.get("office_name", "مكتب النائب لشؤون الفروع")),
                           styles["subtitle"]))
    story.append(Spacer(1, 3 * mm))
    story.append(Paragraph(ar("كشف الملفات المقرر صرفها"), styles["title"]))
    story.append(Paragraph(ar(f"التاريخ: {datetime.now().strftime('%Y-%m-%d')} — "
                              f"عدد الملفات: {len(rows)}"), styles["cell"]))
    story.append(Spacer(1, 3 * mm))

    header = ["م", "رقم الملف", "البرنامج", "الجهة المستفيدة",
              "مبلغ التمويل", "مبلغ الصرف", "رقم القيد", "رقم الشيك"]
    data = [[Paragraph(ar(h), styles["cell_bold"]) for h in header]]
    total = 0
    for i, r in enumerate(rows, 1):
        if (r.get("disburse_amount") or 0):
            total += float(r["disburse_amount"])
        data.append([
            Paragraph(ar(str(i)), styles["cell"]),
            Paragraph(ar(str(r.get("file_number") or "—")), styles["cell"]),
            Paragraph(ar((r.get("program_name") or "—")[:30]), styles["cell"]),
            Paragraph(ar((r.get("beneficiary_name") or "—")[:25]), styles["cell"]),
            Paragraph(ar(format_money(r.get("funding_amount"))), styles["cell"]),
            Paragraph(ar(format_money(r.get("disburse_amount"))), styles["cell"]),
            Paragraph(ar(str(r.get("ledger_number") or "—")), styles["cell"]),
            Paragraph(ar(str(r.get("check_number") or "—")), styles["cell"]),
        ])
    data.append([Paragraph(ar("الإجمالي"), styles["cell_bold"]), "", "", "",
                 "", Paragraph(ar(format_money(total)), styles["cell_bold"]), "", ""])
    widths = [10 * mm, 20 * mm, 42 * mm, 38 * mm, 26 * mm, 26 * mm, 20 * mm, 20 * mm]
    # ملاحظة: الترتيب المعروض يمين→يسار
    data = [list(reversed(row)) for row in data]
    widths = list(reversed(widths))
    t = Table(data, colWidths=widths, repeatRows=1)
    t.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (0, 0), (-1, -1), "RIGHT"),
        ("GRID", (0, 0), (-1, -1), 0.6, BORDER),
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("LEFTPADDING", (0, 0), (-1, -1), 3),
        ("RIGHTPADDING", (0, 0), (-1, -1), 3),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    story.append(t)
    story.append(Spacer(1, 6 * mm))
    story.append(Paragraph(ar("أُعد هذا الكشف لتسليم الملفات الموضحة أعلاه إلى مكتب المدير التنفيذي "
                              "لاستكمال إجراءات الصرف."), styles["cell"]))
    story.append(Spacer(1, 8 * mm))
    sig = [[Paragraph(ar("معد الكشف\nالاسم: ....................\nالتوقيع: ...................."),
                      styles["cell"]),
            Paragraph(ar("اعتماد التسليم\nالاسم: ....................\nالتوقيع: ...................."),
                      styles["cell"])]]
    st = Table(sig, colWidths=[W / 2, W / 2])
    st.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"),
                            ("ALIGN", (0, 0), (-1, -1), "RIGHT")]))
    story.append(st)
    doc.build(story)
    return output_path
