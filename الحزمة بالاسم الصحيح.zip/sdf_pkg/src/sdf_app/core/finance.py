# -*- coding: utf-8 -*-
"""
المحرك المالي المركزي.

كل المعادلات المالية تُنفَّذ هنا فقط (وليس في الواجهة)، باستخدام Decimal
لضمان دقة المبالغ. القيم الناقصة تُعامل كغير متوفرة (None) ولا تُفترض صفرًا.
"""
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Optional, Union

Number = Union[int, float, Decimal, str]


def to_decimal(value) -> Optional[Decimal]:
    """تحويل آمن إلى Decimal. يعيد None للقيم الفارغة/غير الصالحة."""
    if value is None:
        return None
    if isinstance(value, Decimal):
        return value
    if isinstance(value, bool):
        return None
    try:
        text = str(value).strip()
        if not text:
            return None
        # أرقام عربية مشرقية ← لاتينية، وإزالة الفواصل
        ar_digits = "٠١٢٣٤٥٦٧٨٩"
        for i, ch in enumerate(ar_digits):
            text = text.replace(ch, str(i))
        text = text.replace(",", "").replace("٬", "").replace(" ", "")
        return Decimal(text)
    except (InvalidOperation, ValueError, AttributeError):
        return None


CURRENCY_YER = "YER"
CURRENCY_USD = "USD"


def _is_usd(currency) -> bool:
    return (currency or CURRENCY_YER).strip().upper() == CURRENCY_USD


def contract_cost_yer(cost_per_trainee, currency=None, exchange_rate=None) -> Optional[Decimal]:
    """تكلفة الفرد حسب العقد بالريال.

    العقد بالدولار يُحوَّل بسعر الصرف المُدخل؛ وإن غاب السعر (أو لم يكن موجبًا) تُعاد None
    بدل رقم مضلل بالدولار يُعرض على أنه ريال.
    """
    c = to_decimal(cost_per_trainee)
    if c is None:
        return None
    if _is_usd(currency):
        rate = to_decimal(exchange_rate)
        if rate is None or rate <= 0:
            return None
        return c * rate
    return c


def contract_rate_missing(rec: dict) -> bool:
    """عقد بالدولار وتكلفته مُدخلة لكن بلا سعر صرف صالح (لتنبيه المستخدم)."""
    if not _is_usd(rec.get("cost_currency")):
        return False
    if to_decimal(rec.get("contract_cost_per_trainee")) is None:
        return False
    rate = to_decimal(rec.get("exchange_rate"))
    return rate is None or rate <= 0


def contract_total(count, cost_per_trainee) -> Optional[Decimal]:
    """إجمالي العقد = عدد المتدربين حسب العقد × تكلفة الفرد حسب العقد."""
    n, c = to_decimal(count), to_decimal(cost_per_trainee)
    if n is None or c is None:
        return None
    return n * c


def contract_hour_cost(cost_per_trainee, hours) -> Optional[Decimal]:
    """تكلفة الساعة حسب العقد = تكلفة الفرد ÷ عدد الساعات (حماية من القسمة على صفر)."""
    c, h = to_decimal(cost_per_trainee), to_decimal(hours)
    if c is None or h is None or h == 0:
        return None
    return c / h


def approved_total(approved_count, approved_cost_per_trainee) -> Optional[Decimal]:
    """التكلفة الإجمالية المعتمدة = العدد المعتمد × تكلفة المتدرب المعتمدة."""
    n, c = to_decimal(approved_count), to_decimal(approved_cost_per_trainee)
    if n is None or c is None:
        return None
    return n * c


def approved_hour_cost(approved_cost_per_trainee, approved_hours) -> Optional[Decimal]:
    """تكلفة الساعة المعتمدة = تكلفة المتدرب المعتمدة ÷ عدد الساعات المعتمدة."""
    c, h = to_decimal(approved_cost_per_trainee), to_decimal(approved_hours)
    if c is None or h is None or h == 0:
        return None
    return c / h


def diff_funding_claimed(funding_amount, claimed_amount) -> Optional[Decimal]:
    """فارق (أ): مبلغ التمويل − المبلغ المطالب به — كما في معادلة الملف الأصلي (AB)."""
    f, s = to_decimal(funding_amount), to_decimal(claimed_amount)
    if f is None or s is None:
        return None
    return f - s


def diff_claimed_approved(claimed_amount, approved_total_value) -> Optional[Decimal]:
    """فارق (ب): المبلغ المطالب به − المبلغ المعتمد — كما في المواصفات."""
    s, a = to_decimal(claimed_amount), to_decimal(approved_total_value)
    if s is None or a is None:
        return None
    return s - a


def summarize(rec: dict) -> dict:
    """حساب كل المؤشرات المالية لملف واحد. rec: قاموس بحقول الملف."""
    # تكلفة العقد تُحسب دائمًا بالريال: العقود بالدولار تُحوَّل بسعر الصرف
    cost_yer = contract_cost_yer(rec.get("contract_cost_per_trainee"),
                                 rec.get("cost_currency"), rec.get("exchange_rate"))
    ct = contract_total(rec.get("contract_trainees"), cost_yer)
    at = approved_total(rec.get("approved_trainees"), rec.get("approved_cost_per_trainee"))
    return {
        "contract_cost_per_trainee_yer": cost_yer,
        "contract_rate_missing": contract_rate_missing(rec),
        "contract_total": ct,
        "contract_hour_cost": contract_hour_cost(cost_yer, rec.get("contract_hours")),
        "approved_total": at,
        "approved_hour_cost": approved_hour_cost(rec.get("approved_cost_per_trainee"), rec.get("approved_hours")),
        "diff_funding_claimed": diff_funding_claimed(rec.get("funding_amount"), rec.get("claimed_amount")),
        "diff_claimed_approved": diff_claimed_approved(rec.get("claimed_amount"), at),
    }


def quantize_money(value: Optional[Decimal], decimals: int = 2) -> Optional[Decimal]:
    if value is None:
        return None
    exp = Decimal(1).scaleb(-decimals)
    return value.quantize(exp, rounding=ROUND_HALF_UP)


def contract_cost_text(rec: dict, decimals: int = 2, yer_label: str = "ر.ي") -> str:
    """عرض تكلفة الفرد حسب العقد بعملتها الأصلية؛ وللدولار يُضاف المقابل بالريال بين قوسين."""
    c = to_decimal(rec.get("contract_cost_per_trainee"))
    if c is None:
        return "—"
    if _is_usd(rec.get("cost_currency")):
        usd = format_money(c, decimals, "$")
        yer = contract_cost_yer(c, CURRENCY_USD, rec.get("exchange_rate"))
        if yer is None:
            return f"{usd} (سعر الصرف غير مُدخل)"
        return f"{usd} ({format_money(yer, decimals, yer_label)})"
    return format_money(c, decimals, yer_label)


def format_money(value, decimals: int = 2, currency: str = "ر.ي") -> str:
    """تنسيق المبلغ للعرض: فواصل آلاف + العملة. القيم الناقصة → '—'."""
    d = to_decimal(value)
    if d is None:
        return "—"
    q = quantize_money(d, decimals)
    text = f"{q:,.{decimals}f}"
    return f"{text} {currency}".strip()
