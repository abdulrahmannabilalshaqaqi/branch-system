# -*- coding: utf-8 -*-
"""قيم الحقول الرقمية في النماذج: «فارغ» يختلف عن «صفر» (قاعدة: المفقود ≠ صفر).

حقل الأعداد في النموذج (QSpinBox) حدّه الأدنى EMPTY_INT ويُعرض «—»؛ فيبقى الحقل الذي لم
يُدخل NULL في القاعدة بدل أن يُحفظ صفرًا، فلا ينهار العدد المقترح ولا يتجاوز مانع الاعتماد.
"""
from typing import Optional

EMPTY_INT = -1


def spin_to_value(v) -> Optional[int]:
    """قيمة الحقل في النموذج ← القيمة المخزنة: الفارغ → None، والصفر يبقى صفرًا."""
    if v is None or v < 0:
        return None
    return int(v)


def value_to_spin(val) -> int:
    """القيمة المخزنة ← قيمة الحقل في النموذج: None/فارغ/غير رقمي → EMPTY_INT."""
    if val in (None, ""):
        return EMPTY_INT
    try:
        return max(int(val), 0)
    except (TypeError, ValueError):
        return EMPTY_INT
