# -*- coding: utf-8 -*-
"""إدارة الاتصال بقاعدة SQLite وتطبيق المخطط/الترحيلات."""
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Optional

from .. import config

SCHEMA_VERSION = 4
KEEP_PRE_MIGRATION_BACKUPS = 5


def _schema_sql() -> str:
    from .. import config
    return config.resource_path("database", "schema.sql").read_text(encoding="utf-8")


class Database:
    def __init__(self, path: Optional[Path] = None):
        self.path = Path(path) if path else config.db_path()
        self._conn: Optional[sqlite3.Connection] = None

    def connect(self) -> sqlite3.Connection:
        if self._conn is None:
            config.ensure_data_dirs()
            conn = sqlite3.connect(str(self.path))
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA foreign_keys = ON")
            conn.execute("PRAGMA journal_mode = WAL")
            try:
                self._backup_before_migration(conn)
                self._migrate(conn)
            except Exception:
                conn.close()  # لا نُبقي اتصالًا بقاعدة نصف مرحَّلة؛ المحاولة التالية تبدأ من جديد
                raise
            self._conn = conn
        return self._conn

    @property
    def is_open(self) -> bool:
        return self._conn is not None

    def close(self):
        if self._conn is not None:
            self._conn.commit()
            self._conn.close()
            self._conn = None

    # -- الترحيلات ------------------------------------------------------
    def _backup_before_migration(self, conn: sqlite3.Connection):
        """نسخة أمان من قاعدة قائمة قبل ترقية مخططها (لا تُنشأ لقاعدة جديدة أو محدَّثة).
        تُحفظ بجوار القاعدة في backups/ ويُبقى آخر KEEP_PRE_MIGRATION_BACKUPS نسخ."""
        version = self._current_version(conn)
        if version < 1 or version >= SCHEMA_VERSION:
            return
        backups = self.path.parent / "backups"
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        target_path = backups / f"pre_migration_v{version}_{stamp}.db"
        try:
            backups.mkdir(parents=True, exist_ok=True)
            target = sqlite3.connect(str(target_path))
            try:
                with target:
                    conn.backup(target)
            finally:
                target.close()
        except Exception as exc:
            target_path.unlink(missing_ok=True)
            raise RuntimeError("تعذّر إنشاء نسخة أمان قبل ترقية قاعدة البيانات؛ لم تُجرَ الترقية "
                               f"ولم تتأثر بياناتك. السبب: {exc}") from exc
        old = sorted(backups.glob("pre_migration_v*.db"),
                     key=lambda p: p.stat().st_mtime, reverse=True)
        for p in old[KEEP_PRE_MIGRATION_BACKUPS:]:
            p.unlink(missing_ok=True)

    def _current_version(self, conn: sqlite3.Connection) -> int:
        try:
            row = conn.execute("SELECT MAX(version) AS v FROM schema_migrations").fetchone()
            return int(row["v"]) if row and row["v"] is not None else 0
        except sqlite3.OperationalError:
            return 0

    def _migrate(self, conn: sqlite3.Connection):
        version = self._current_version(conn)
        if version < 1:
            conn.executescript(_schema_sql())
            conn.execute("INSERT INTO schema_migrations (version) VALUES (1)")
            conn.commit()
        if version < 2:
            cols = {c[1] for c in conn.execute("PRAGMA table_info(training_files)")}
            if "contract_number" not in cols:
                conn.execute("ALTER TABLE training_files ADD COLUMN contract_number TEXT")
            conn.execute("INSERT INTO schema_migrations (version) VALUES (2)")
            conn.commit()
        if version < 3:
            self._migrate_v3(conn)
            conn.execute("INSERT INTO schema_migrations (version) VALUES (3)")
            conn.commit()
        if version < 4:
            self._migrate_v4(conn)
            conn.execute("INSERT INTO schema_migrations (version) VALUES (4)")
            conn.commit()

    def _migrate_v4(self, conn: sqlite3.Connection):
        """إلزام تغيير كلمة المرور الافتراضية: عمود must_change_password.

        يُفعَّل فقط للحسابات التي ما زالت كلمة مرورها الافتراضية (admin123) —
        من غيّر كلمته لا يُطالب بشيء.
        """
        from ..services.auth_service import verify_password
        cols = {c[1] for c in conn.execute("PRAGMA table_info(users)")}
        if "must_change_password" not in cols:
            conn.execute("ALTER TABLE users "
                         "ADD COLUMN must_change_password INTEGER NOT NULL DEFAULT 0")
        for row in conn.execute("SELECT id, password_hash FROM users WHERE active=1"):
            try:
                if verify_password("admin123", row["password_hash"]):
                    conn.execute("UPDATE users SET must_change_password=1 WHERE id=?",
                                 (row["id"],))
            except Exception:
                continue

    # -- الترحيل v3: حزمة التعديلات v2 --------------------------------------
    def _migrate_v3(self, conn: sqlite3.Connection):
        from ..core.workflow import STATUSES, TRANSITIONS

        def add_column(table: str, ddl: str):
            cols = {c[1] for c in conn.execute(f"PRAGMA table_info({table})")}
            name = ddl.split()[0].strip('"')
            if name not in cols:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN {ddl}")

        # -- أعمدة جديدة في training_files ----------------------------------
        for ddl in [
            "group_name TEXT",            # المجموعة
            "level TEXT",                 # المستوى
            "exec_place TEXT",            # مكان التنفيذ
            "clearance_number TEXT",      # رقم التسميح
            "cost_currency TEXT DEFAULT 'YER'",  # عملة التكلفة: YER / USD
            "exchange_rate REAL",         # سعر الصرف (للدولار)
            "attendance_exec_match TEXT", # تاريخ التنفيذ حسب الحضور: مطابق/غير مطابق
            "supervision_date TEXT",      # تاريخ يوم الإشراف
            "cert_program_match TEXT",    # اسم البرنامج في الشهادة: مطابق/غير مطابق
            "cert_exec_match TEXT",       # تاريخ التنفيذ في الشهادة: مطابق/غير مطابق
            "material_file_id INTEGER REFERENCES training_files(id)",
            "program_id INTEGER REFERENCES programs(id)",
            "disburse_amount REAL",       # مبلغ الصرف
            "ledger_number TEXT",         # رقم القيد
            "check_number TEXT",          # رقم الشيك
            "check_received_date TEXT",   # تاريخ استلام الشيك
            "recipient_name TEXT",        # اسم المستلم
            "delivered_to_director_date TEXT",  # تاريخ التسليم لمكتب المدير التنفيذي
        ]:
            add_column("training_files", ddl)

        # -- أعمدة الجهات ----------------------------------------------------
        add_column("entities", "tax_number TEXT")       # الرقم الضريبي
        add_column("entities", "employee_count INTEGER")  # عدد الموظفين

        # -- أعمدة الترشيح والحضور --------------------------------------------
        add_column("trainees_nomination", "beneficiary_id INTEGER REFERENCES entities(id)")
        add_column("trainees_attendance", "days_attended INTEGER")
        add_column("trainees_attendance", "in_supervision_report INTEGER")

        # -- جدول البرامج التدريبية (قائمة مقيدة) ------------------------------
        conn.execute("""
            CREATE TABLE IF NOT EXISTS programs (
                id     INTEGER PRIMARY KEY AUTOINCREMENT,
                name   TEXT NOT NULL UNIQUE,
                active INTEGER NOT NULL DEFAULT 1
            )""")
        # تعبئة من الأسماء الموجودة وربطها
        for r in conn.execute(
                "SELECT DISTINCT program_name FROM training_files WHERE program_name IS NOT NULL"
                " AND TRIM(program_name) <> ''"):
            conn.execute("INSERT OR IGNORE INTO programs (name) VALUES (?)", (r["program_name"],))
        conn.execute("""
            UPDATE training_files SET program_id =
                (SELECT id FROM programs WHERE programs.name = training_files.program_name)
            WHERE program_id IS NULL AND program_name IS NOT NULL""")

        # -- المساهمات الشهرية --------------------------------------------------
        conn.execute("""
            CREATE TABLE IF NOT EXISTS contributions (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_id INTEGER NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
                year      INTEGER NOT NULL,
                month     INTEGER NOT NULL CHECK (month BETWEEN 1 AND 12),
                amount    REAL NOT NULL DEFAULT 0,
                kind      TEXT NOT NULL DEFAULT 'monthly'
                          CHECK (kind IN ('monthly', 'previous_period')),
                notes     TEXT,
                created_by INTEGER REFERENCES users(id),
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                UNIQUE (entity_id, year, month, kind)
            )""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_contrib_entity "
                     "ON contributions(entity_id, year, month)")
        # سجل نسب رصيد التدريب مع تاريخ السريان
        conn.execute("""
            CREATE TABLE IF NOT EXISTS contribution_rates (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                rate           REAL NOT NULL,
                effective_from TEXT NOT NULL,
                created_by     INTEGER REFERENCES users(id),
                created_at     TEXT NOT NULL DEFAULT (datetime('now'))
            )""")
        if conn.execute("SELECT COUNT(*) c FROM contribution_rates").fetchone()["c"] == 0:
            conn.execute("INSERT INTO contribution_rates (rate, effective_from) VALUES (0.5, '2000-01-01')")
        # استثناءات رصيد العام السابق
        conn.execute("""
            CREATE TABLE IF NOT EXISTS entity_year_exceptions (
                id                  INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_id           INTEGER NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
                year                INTEGER NOT NULL,
                allow_previous_year INTEGER NOT NULL DEFAULT 0,
                notes               TEXT,
                UNIQUE (entity_id, year)
            )""")

        # -- مصفوفة الصلاحيات (دور / مستخدم) -------------------------------------
        conn.execute("""
            CREATE TABLE IF NOT EXISTS role_permissions (
                role       TEXT NOT NULL,
                permission TEXT NOT NULL,
                allowed    INTEGER NOT NULL DEFAULT 1,
                PRIMARY KEY (role, permission)
            )""")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS user_permissions (
                user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                permission TEXT NOT NULL,
                allowed    INTEGER NOT NULL DEFAULT 1,
                PRIMARY KEY (user_id, permission)
            )""")

        # -- كشوفات الصرف ---------------------------------------------------------
        conn.execute("""
            CREATE TABLE IF NOT EXISTS disbursement_lists (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                title        TEXT,
                created_at   TEXT NOT NULL DEFAULT (datetime('now')),
                created_by   INTEGER REFERENCES users(id),
                confirmed_at TEXT,
                confirmed_by INTEGER REFERENCES users(id),
                notes        TEXT
            )""")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS disbursement_list_items (
                list_id INTEGER NOT NULL REFERENCES disbursement_lists(id) ON DELETE CASCADE,
                file_id INTEGER NOT NULL REFERENCES training_files(id) ON DELETE CASCADE,
                PRIMARY KEY (list_id, file_id)
            )""")

        # -- الحالات الجديدة + إعادة ترتيب sort_order ------------------------------
        order = {code: i for i, (code, _n, _t) in enumerate(STATUSES)}
        for code, name, terminal in STATUSES:
            conn.execute(
                "INSERT OR IGNORE INTO file_statuses (code, name, sort_order, is_terminal)"
                " VALUES (?,?,?,?)", (code, name, order[code], terminal))
            conn.execute("UPDATE file_statuses SET name=?, sort_order=?, is_terminal=? WHERE code=?",
                         (name, order[code], terminal, code))
        ids = {r["code"]: r["id"] for r in conn.execute("SELECT id, code FROM file_statuses")}
        for fc, tc in TRANSITIONS:
            if fc in ids and tc in ids:
                conn.execute("INSERT OR IGNORE INTO status_transitions (from_status_id, to_status_id)"
                             " VALUES (?,?)", (ids[fc], ids[tc]))


_db_instance: Optional[Database] = None


def get_database(path: Optional[Path] = None) -> Database:
    global _db_instance
    if _db_instance is None or (path is not None and _db_instance.path != Path(path)):
        _db_instance = Database(path)
    return _db_instance


def reset_database_singleton():
    global _db_instance
    if _db_instance is not None:
        _db_instance.close()
    _db_instance = None
