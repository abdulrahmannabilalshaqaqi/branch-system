# -*- coding: utf-8 -*-
"""صفحة الجهات المستفيدة: الاسم، الرقم الضريبي، عدد الموظفين (إضافة/تعديل/حذف)."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QComboBox, QDialog, QDialogButtonBox,
                               QFormLayout, QHBoxLayout, QLabel, QLineEdit,
                               QMessageBox, QPushButton, QSpinBox,
                               QTableWidget, QTableWidgetItem, QVBoxLayout,
                               QWidget)

from ..services.auth_service import has_permission
from .widgets import rtl_align


class EntitiesPage(QWidget):
    COLUMNS = [("name", "اسم الجهة"), ("tax_number", "الرقم الضريبي"),
               ("employee_count", "عدد الموظفين")]

    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        layout = QVBoxLayout(self)

        top = QHBoxLayout()
        top.addWidget(QLabel("النوع:"))
        self.kind_cb = QComboBox()
        self.kind_cb.addItem("الجهات المستفيدة", "beneficiary")
        self.kind_cb.addItem("الجهات المنفذة", "implementing")
        self.kind_cb.currentIndexChanged.connect(self.refresh)
        top.addWidget(self.kind_cb)
        top.addStretch(1)
        layout.addLayout(top)

        self.table = QTableWidget()
        self.table.setColumnCount(len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels([t for _, t in self.COLUMNS])
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        self.table.doubleClicked.connect(self.edit_entity)
        layout.addWidget(self.table, 1)

        row = QHBoxLayout()
        self.btn_add = QPushButton("＋ إضافة جهة")
        self.btn_add.setProperty("primary", True)
        self.btn_add.clicked.connect(self.add_entity)
        self.btn_edit = QPushButton("تعديل")
        self.btn_edit.clicked.connect(self.edit_entity)
        self.btn_del = QPushButton("حذف")
        self.btn_del.clicked.connect(self.delete_entity)
        row.addWidget(self.btn_add)
        row.addWidget(self.btn_edit)
        row.addWidget(self.btn_del)
        row.addStretch(1)
        layout.addLayout(row)
        rtl_align(self)

    def _can_manage(self):
        return has_permission(self.ctx.user, "settings.manage", self.ctx.conn)

    def refresh(self):
        kind = self.kind_cb.currentData()
        rows = self.ctx.conn.execute(
            "SELECT id, name, tax_number, employee_count FROM entities"
            " WHERE kind=? AND active=1 ORDER BY name", (kind,)).fetchall()
        self._rows = [dict(r) for r in rows]
        self.table.setRowCount(len(self._rows))
        for i, r in enumerate(self._rows):
            for j, (key, _t) in enumerate(self.COLUMNS):
                v = r.get(key)
                item = QTableWidgetItem(str(v) if v not in (None, "") else "—")
                item.setData(Qt.UserRole, r["id"])
                if key == "employee_count":
                    item.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(i, j, item)
        self.table.resizeColumnsToContents()

    def _selected_id(self):
        row = self.table.currentRow()
        if row < 0:
            return None
        return self.table.item(row, 0).data(Qt.UserRole)

    def add_entity(self):
        if not self._can_manage():
            QMessageBox.warning(self, "صلاحيات", "لا تملك صلاحية إدارة الجهات.")
            return
        dlg = EntityDialog(self.ctx, self.kind_cb.currentData(), parent=self)
        if dlg.exec():
            self.refresh()

    def edit_entity(self):
        eid = self._selected_id()
        if not eid:
            QMessageBox.information(self, "تنبيه", "اختر جهة أولًا.")
            return
        if not self._can_manage():
            QMessageBox.warning(self, "صلاحيات", "لا تملك صلاحية إدارة الجهات.")
            return
        dlg = EntityDialog(self.ctx, self.kind_cb.currentData(), entity_id=eid, parent=self)
        if dlg.exec():
            self.refresh()

    def delete_entity(self):
        eid = self._selected_id()
        if not eid:
            return
        if not self._can_manage():
            QMessageBox.warning(self, "صلاحيات", "لا تملك صلاحية إدارة الجهات.")
            return
        used = self.ctx.conn.execute(
            "SELECT COUNT(*) c FROM training_files WHERE beneficiary_id=? OR implementing_id=?",
            (eid, eid)).fetchone()["c"]
        if used:
            QMessageBox.warning(self, "تعذر الحذف",
                                f"الجهة مرتبطة بـ {used} ملف — سيتم إيقافها بدل الحذف.")
        if QMessageBox.question(self, "تأكيد", "إيقاف هذه الجهة؟") != QMessageBox.Yes:
            return
        self.ctx.conn.execute("UPDATE entities SET active=0 WHERE id=?", (eid,))
        self.ctx.conn.commit()
        self.refresh()


class EntityDialog(QDialog):
    def __init__(self, ctx, kind, entity_id=None, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.entity_id = entity_id
        self.kind = kind
        title = "جهة مستفيدة" if kind == "beneficiary" else "جهة منفذة"
        self.setWindowTitle(("إضافة " if not entity_id else "تعديل ") + title)
        form = QFormLayout(self)
        form.setLabelAlignment(Qt.AlignRight)
        self.name = QLineEdit()
        self.tax = QLineEdit()
        self.employees = QSpinBox()
        self.employees.setRange(0, 1000000)
        form.addRow("اسم الجهة *:", self.name)
        if kind == "beneficiary":
            form.addRow("الرقم الضريبي:", self.tax)
            form.addRow("عدد الموظفين:", self.employees)
        btns = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        btns.button(QDialogButtonBox.Save).setText("حفظ")
        btns.button(QDialogButtonBox.Save).setProperty("primary", True)
        btns.button(QDialogButtonBox.Cancel).setText("إلغاء")
        btns.accepted.connect(self.save)
        btns.rejected.connect(self.reject)
        form.addRow(btns)
        if entity_id:
            r = ctx.conn.execute("SELECT * FROM entities WHERE id=?", (entity_id,)).fetchone()
            if r:
                self.name.setText(r["name"] or "")
                self.tax.setText(r["tax_number"] or "")
                self.employees.setValue(r["employee_count"] or 0)
        rtl_align(self)

    def save(self):
        name = self.name.text().strip()
        if not name:
            QMessageBox.warning(self, "تنبيه", "اسم الجهة إلزامي.")
            return
        uid = self.ctx.user["id"] if self.ctx.user else None
        try:
            if self.entity_id:
                self.ctx.conn.execute(
                    "UPDATE entities SET name=?, tax_number=?, employee_count=? WHERE id=?",
                    (name, self.tax.text().strip() or None,
                     self.employees.value() or None, self.entity_id))
            else:
                self.ctx.conn.execute(
                    "INSERT INTO entities (name, kind, tax_number, employee_count) VALUES (?,?,?,?)",
                    (name, self.kind, self.tax.text().strip() or None,
                     self.employees.value() or None))
            self.ctx.conn.commit()
            self.accept()
        except Exception as exc:
            QMessageBox.warning(self, "تعذر الحفظ", f"ربما الاسم مكرر: {exc}")
