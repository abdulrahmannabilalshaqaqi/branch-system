# -*- coding: utf-8 -*-
"""نقطة الدخول الرئيسية للبرنامج."""
import logging
import sys
import traceback

from PySide6.QtWidgets import QDialog, QMessageBox

from sdf_app import config
from sdf_app.ui.app import create_app
from sdf_app.ui.context import AppContext
from sdf_app.ui.login_dialog import LoginDialog
from sdf_app.ui.main_window import MainWindow


def _setup_logging():
    """سجل أخطاء في ملف داخل مجلد بيانات البرنامج (لا يُعرض للمستخدم)."""
    try:
        log_dir = config.logs_dir()
        log_dir.mkdir(parents=True, exist_ok=True)
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s %(levelname)s %(name)s: %(message)s",
            handlers=[logging.FileHandler(log_dir / "app.log", encoding="utf-8"),
                      logging.StreamHandler(sys.stderr)],
            force=True,
        )
    except Exception:
        logging.basicConfig(level=logging.INFO)


def _wire_pages(window: MainWindow, ctx: AppContext):
    from sdf_app.ui.contributions_page import ContributionsPage
    from sdf_app.ui.dashboard_page import DashboardPage
    from sdf_app.ui.disbursement_page import DisbursementPage
    from sdf_app.ui.entities_page import EntitiesPage
    from sdf_app.ui.files_page import FilesPage
    from sdf_app.ui.import_wizard import ImportWizard
    from sdf_app.ui.reports_page import ReportsPage
    from sdf_app.ui.review_page import ReviewPage
    from sdf_app.ui.settings_page import SettingsPage

    def navigate(page_key: str, filters: dict = None):
        window.show_page(page_key)
        if page_key == "files" and filters and "files" in window.pages:
            window.pages["files"].set_filters(filters)

    dashboard = DashboardPage(ctx, on_navigate=navigate)
    files_page = FilesPage(ctx)
    review_page = ReviewPage(ctx)
    reports_page = ReportsPage(ctx)
    settings_page = SettingsPage(ctx)
    disburse_page = DisbursementPage(ctx)
    entities_page = EntitiesPage(ctx)
    contributions_page = ContributionsPage(ctx)

    def open_import():
        wiz = ImportWizard(ctx, window)
        if wiz.exec():
            files_page.refresh()
            dashboard.refresh()

    # صفحة الاستيراد تُفتح كمعالج
    import_page = None

    def open_file(file_id: int, open_review: bool = False):
        if open_review:
            review_page.open_file(file_id)
            window.show_page("review")
        else:
            from sdf_app.ui.file_dialog import FileDialog
            dlg = FileDialog(ctx, file_id=file_id, parent=window)
            if dlg.exec():
                files_page.refresh()

    files_page.on_open_file = open_file
    review_page.on_print_form = lambda fid: reports_page.open_form_for_file(fid)

    window.register_page("dashboard", "لوحة التحكم", dashboard)
    window.register_page("files", "إدارة الملفات", files_page)
    window.register_page("review", "المراجعة الفنية", review_page)
    window.register_page("disburse", "الصرف", disburse_page)
    window.register_page("entities", "الجهات المستفيدة", entities_page)
    window.register_page("contributions", "المساهمات الشهرية", contributions_page)
    window.register_page("reports", "التقارير والطباعة", reports_page)
    window.register_page("settings", "الإعدادات", settings_page)
    window.register_page("users", "المستخدمون", settings_page)
    window.register_page("backup", "النسخ الاحتياطي", settings_page)

    # زر الاستيراد في القائمة يفتح المعالج مباشرة
    for btn in window.nav_group.buttons():
        if btn.property("page_key") == "import":
            btn.clicked.disconnect()
            btn.clicked.connect(open_import)

    window.show_page("dashboard")
    return {"dashboard": dashboard, "files": files_page}


def main(argv=None) -> int:
    argv = sys.argv if argv is None else argv
    _setup_logging()
    log = logging.getLogger("sdf_app")

    app = create_app(argv)
    try:
        config.ensure_data_dirs()
        ctx = AppContext()
    except Exception:
        log.exception("فشل تهيئة قاعدة البيانات")
        QMessageBox.critical(
            None, "خطأ في قاعدة البيانات",
            "تعذر فتح قاعدة البيانات، ولن يعمل البرنامج.\n\n"
            "سُجّلت تفاصيل الخطأ في ملف السجل (logs/app.log) داخل مجلد بيانات البرنامج.")
        return 1

    login = LoginDialog(ctx)
    if login.exec() != QDialog.Accepted:
        return 0

    window = MainWindow(ctx)
    try:
        _wire_pages(window, ctx)
    except Exception:
        log.exception("فشل تحميل الواجهة")
        QMessageBox.critical(None, "خطأ", f"فشل تحميل الواجهة:\n{traceback.format_exc()}")
        return 1
    window.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
