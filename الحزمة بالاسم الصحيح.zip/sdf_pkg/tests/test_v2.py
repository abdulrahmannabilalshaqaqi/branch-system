# -*- coding: utf-8 -*-
"""اختبارات حزمة التعديلات v2: الحالات الجديدة، النسخ، الصرف، المساهمات، الصلاحيات، الاستمارات."""
import sqlite3
from pathlib import Path

import pytest

from sdf_app.core.workflow import can_transition, next_statuses, STATUS_NAMES
from sdf_app.database.connection import Database
from sdf_app.database.seeds import seed_all
from sdf_app.services import contribution_service as contrib
from sdf_app.services.auth_service import (has_permission, set_role_permission,
                                           set_user_permission, create_user)
from sdf_app.services.file_service import FileService


@pytest.fixture()
def conn(tmp_path):
    db = Database(tmp_path / "t.db")
    c = db.connect()
    seed_all(c)
    yield c
    db.close()


def _make_file(conn, num=1, **kw):
    fs = FileService(conn)
    data = {"file_number": num, "program_name": "برنامج", "received_date": "2024-01-05"}
    data.update(kw)
    return fs.create(data, user_id=1)


def _status_id(conn, code):
    return conn.execute("SELECT id FROM file_statuses WHERE code=?", (code,)).fetchone()["id"]


# -- الحالات الجديدة ---------------------------------------------------------------
def test_new_statuses_exist(conn):
    for code in ("ready_disburse", "disbursing", "disbursed"):
        assert code in STATUS_NAMES
        assert conn.execute("SELECT 1 FROM file_statuses WHERE code=?", (code,)).fetchone()


def test_disburse_flow_transitions():
    assert can_transition("approved", "ready_disburse")
    assert can_transition("ready_disburse", "disbursing")
    assert can_transition("disbursing", "disbursed")
    assert "disbursing" in next_statuses("ready_disburse")


def test_migration_v3_on_old_db(tmp_path):
    p = tmp_path / "old3.db"
    c = Database(p).connect()
    c.execute("DELETE FROM schema_migrations WHERE version=3")
    c.execute("DELETE FROM schema_migrations WHERE version=4")
    c.execute("ALTER TABLE training_files DROP COLUMN clearance_number")
    c.execute("DROP TABLE IF EXISTS contributions")
    c.execute("DROP TABLE IF EXISTS programs")
    c.commit()
    c.close()
    c2 = Database(p).connect()
    assert c2.execute("SELECT MAX(version) FROM schema_migrations").fetchone()[0] == 4
    cols = {r[1] for r in c2.execute("PRAGMA table_info(training_files)")}
    for col in ("clearance_number", "group_name", "level", "exec_place", "cost_currency",
                "exchange_rate", "attendance_exec_match", "supervision_date",
                "cert_program_match", "cert_exec_match", "material_file_id", "program_id",
                "disburse_amount", "ledger_number", "check_number", "check_received_date",
                "recipient_name", "delivered_to_director_date"):
        assert col in cols, col
    assert c2.execute("SELECT 1 FROM file_statuses WHERE code='disbursed'").fetchone()
    assert c2.execute("SELECT rate FROM contribution_rates").fetchone()["rate"] == 0.5
    c2.close()


# -- نسخ الملف ----------------------------------------------------------------------
def test_duplicate_file(conn):
    fs = FileService(conn)
    src = _make_file(conn, 701, program_name="برنامج أ", clearance_number="ت/1")
    conn.execute("INSERT INTO trainees_nomination (file_id, seq, full_name) VALUES (?,?,?)",
                 (src, 1, "مرشح واحد"))
    conn.execute("INSERT INTO trainees_attendance (file_id, seq, full_name, days_attended,"
                 " in_supervision_report) VALUES (?,?,?,?,?)", (src, 1, "مرشح واحد", 10, 1))
    conn.commit()
    new_id = fs.duplicate_file(src, 702, user_id=1)
    rec = fs.get(new_id)
    assert rec["file_number"] == 702
    assert rec["program_name"] == "برنامج أ"
    assert rec["status_code"] == "new"
    assert conn.execute("SELECT COUNT(*) c FROM trainees_nomination WHERE file_id=?",
                        (new_id,)).fetchone()["c"] == 1
    assert conn.execute("SELECT COUNT(*) c FROM trainees_attendance WHERE file_id=?",
                        (new_id,)).fetchone()["c"] == 1


def test_duplicate_file_number_conflict(conn):
    fs = FileService(conn)
    a = _make_file(conn, 711)
    _make_file(conn, 712)
    with pytest.raises(ValueError):
        fs.duplicate_file(a, 712, user_id=1)


# -- الصرف ---------------------------------------------------------------------------
def _to_ready_disburse(conn, fid):
    fs = FileService(conn)
    for code in ("received", "tech_review", "tech_done", "finance_review",
                 "ready_approve", "approved", "ready_disburse"):
        try:
            fs.change_status(fid, code, user_id=1, force_exception=True,
                             notes="تجهيز اختبار")  # الاستثناء الموثق يتطلب سببًا
        except ValueError:
            pass
    return fs.get(fid)


def test_disbursement_full_flow(conn):
    fs = FileService(conn)
    fid = _make_file(conn, 721, funding_amount=100000)
    _to_ready_disburse(conn, fid)
    assert fs.get(fid)["status_code"] == "ready_disburse"
    res = fs.confirm_delivery_to_director([fid], user_id=1)
    assert res["done"] == [fid] and not res["errors"]
    rec = fs.get(fid)
    assert rec["status_code"] == "disbursing"
    assert rec["delivered_to_director_date"]
    # حفظ بيانات ناقصة لا يُكمل الصرف
    st = fs.save_disbursement_data(fid, {"ledger_number": "ق/5"}, user_id=1)
    assert st == "disbursing"
    # اكتمال الشيك والقيد ← منصرفة
    st = fs.save_disbursement_data(
        fid, {"check_number": "ش/9", "check_received_date": "2026-01-02",
              "recipient_name": "أحمد", "disburse_amount": 100000}, user_id=1)
    assert st == "disbursed"
    assert fs.get(fid)["status_code"] == "disbursed"
    # البحث برقم القيد/الشيك
    rows = fs.search_disbursed("ش/9")
    assert len(rows) == 1 and rows[0]["file_number"] == 721
    rows = fs.search_disbursed("ق/5")
    assert len(rows) == 1


def test_confirm_delivery_requires_ready_disburse(conn):
    fs = FileService(conn)
    fid = _make_file(conn, 722)
    res = fs.confirm_delivery_to_director([fid], user_id=1)
    assert res["done"] == [] and res["errors"]


# -- المساهمات -------------------------------------------------------------------------
def _beneficiary(conn, name="جهة أ"):
    cur = conn.execute(
        "INSERT INTO entities (name, kind, tax_number, employee_count) VALUES (?,?,?,?)",
        (name, "beneficiary", "123", 50))
    conn.commit()
    return cur.lastrowid


def test_contribution_balance(conn):
    eid = _beneficiary(conn)
    contrib.upsert_contribution(conn, eid, 2026, 1, 100000, kind="monthly", user_id=1)
    contrib.upsert_contribution(conn, eid, 2026, 2, 100000, kind="monthly", user_id=1)
    contrib.upsert_contribution(conn, eid, 2026, 3, 50000, kind="previous_period", user_id=1)
    bal = contrib.entity_balance(conn, eid, 2026)
    assert bal["contributions"] == 250000
    assert bal["rate"] == 0.5
    assert bal["training_balance"] == 125000
    assert bal["remaining"] == 125000
    # ملف بتمويل يُخصم من الرصيد
    _make_file(conn, 731, beneficiary_id=eid, funding_amount=25000, exec_start="2026-03-01")
    bal = contrib.entity_balance(conn, eid, 2026)
    assert bal["funding_used"] == 25000
    assert bal["remaining"] == 100000


def test_contribution_rate_change_with_effective_date(conn):
    eid = _beneficiary(conn, "جهة ب")
    contrib.upsert_contribution(conn, eid, 2026, 1, 100000, user_id=1)
    contrib.set_rate(conn, 0.6, "2026-06-01", user_id=1)
    # سارية لنهاية 2026 ← 60%
    assert contrib.current_rate(conn, "2026-12-31") == 0.6
    # قبل السريان ← 50%
    assert contrib.current_rate(conn, "2026-01-01") == 0.5
    bal = contrib.entity_balance(conn, eid, 2026)
    # مساهمة يناير تسبق تاريخ السريان (يونيو) فتبقى بنسبة 50% — لا أثر رجعي للنسبة الجديدة
    assert bal["training_balance"] == 50000
    contrib.upsert_contribution(conn, eid, 2026, 6, 100000, user_id=1)  # بعد السريان ← 60%
    bal = contrib.entity_balance(conn, eid, 2026)
    assert bal["training_balance"] == 110000


def test_previous_year_exception(conn):
    eid = _beneficiary(conn, "جهة ج")
    contrib.upsert_contribution(conn, eid, 2025, 1, 200000, user_id=1)
    contrib.upsert_contribution(conn, eid, 2026, 1, 100000, user_id=1)
    bal = contrib.entity_balance(conn, eid, 2026)
    assert bal["carried_from_previous"] == 0  # بلا استثناء
    contrib.set_exception(conn, eid, 2026, True, user_id=1)
    bal = contrib.entity_balance(conn, eid, 2026)
    # رصيد 2025: 200000*50% = 100000 مرحّل
    assert bal["carried_from_previous"] == 100000
    assert bal["remaining"] == 150000


def test_balance_before_file(conn):
    eid = _beneficiary(conn, "جهة د")
    contrib.upsert_contribution(conn, eid, 2026, 1, 200000, user_id=1)
    _make_file(conn, 741, beneficiary_id=eid, funding_amount=20000, exec_start="2026-02-01")
    _make_file(conn, 742, beneficiary_id=eid, funding_amount=30000, exec_start="2026-05-01")
    info = contrib.balance_before_file(conn, eid, 2026, 742)
    assert info["entity_year_serial"] == 2
    assert info["used_before_file"] == 20000
    assert info["remaining_before_file"] == 80000  # 100000 - 20000


# -- الصلاحيات --------------------------------------------------------------------------
def _admin_user():
    return {"id": 1, "username": "admin", "role": "admin"}


def test_role_permission_override(conn):
    user = {"id": 99, "username": "x", "role": "viewer"}
    assert not has_permission(user, "file.create", conn)
    set_role_permission(conn, "viewer", "file.create", True, actor_id=1)
    assert has_permission(user, "file.create", conn)
    set_role_permission(conn, "viewer", "file.create", False, actor_id=1)
    assert not has_permission(user, "file.create", conn)


def test_user_permission_override_beats_role(conn):
    uid = create_user(conn, "u1", "مستخدم", "secret1", "viewer", actor_id=1)
    user = {"id": uid, "username": "u1", "role": "viewer"}
    assert has_permission(user, "export", conn)  # الافتراضي: ممنوح
    set_user_permission(conn, uid, "export", False, actor_id=1)
    assert not has_permission(user, "export", conn)
    # تجاوز الدور لا يؤثر على المستخدم المخصص
    set_role_permission(conn, "viewer", "export", True, actor_id=1)
    assert not has_permission(user, "export", conn)


def test_admin_has_all_even_new_permissions(conn):
    assert has_permission(_admin_user(), "disburse.manage", conn)
    assert has_permission(_admin_user(), "contrib.manage", conn)


# -- إحصاءات اللوحة -----------------------------------------------------------------------
def test_dashboard_stats_v2(conn):
    fs = FileService(conn)
    bid = conn.execute("INSERT INTO branches (name) VALUES ('فرع1')").lastrowid
    conn.commit()
    _make_file(conn, 751, branch_id=bid, exec_start="2026-04-10",
               claimed_amount=50000, funding_amount=40000, approved_trainees=10)
    _make_file(conn, 752, branch_id=bid, exec_start="2026-04-12",
               claimed_amount=30000, funding_amount=30000, approved_trainees=5)
    stats = fs.dashboard_stats()
    assert stats["sums"]["funding"] == 70000
    assert stats["sums"]["claimed"] == 80000
    assert stats["trainees_total"] == 15
    assert any(r["ym"] == "2026-04" and r["c"] == 2 for r in stats["by_month"])
    # ترشيح ذاتي بالفرع
    f2 = fs.dashboard_stats(filters={"branch_id": bid})
    assert f2["total"] == 2
    f3 = fs.dashboard_stats(filters={"branch_id": 99999})
    assert f3["total"] == 0


# -- الاستمارات PDF -------------------------------------------------------------------------
def _rich_file(conn):
    fs = FileService(conn)
    bid = conn.execute("INSERT INTO branches (name) VALUES ('فرع التسميح')").lastrowid
    eid = _beneficiary(conn, "جهة التسميح")
    conn.commit()
    fid = _make_file(conn, 761, branch_id=bid, beneficiary_id=eid,
                     program_name="برنامج التسميح", exec_start="2026-03-01",
                     exec_end="2026-03-10", funding_amount=50000,
                     approved_trainees=20, approved_hours=40,
                     approved_cost_per_trainee=2500, claimed_amount=55000,
                     attendance_exec_match="مطابق", cert_program_match="مطابق",
                     cert_exec_match="غير مطابق", material_match="مطابق")
    return fs.get(fid)


def test_review_form_single_page(tmp_path, conn):
    from pypdf import PdfReader
    from sdf_app.reports.review_form import build_review_form
    rec = _rich_file(conn)
    out = tmp_path / "form.pdf"
    build_review_form(rec, [], out, settings={"org_name": "صندوق تنمية المهارات",
                                              "office_name": "مكتب النائب لشؤون الفروع"})
    assert out.exists()
    assert len(PdfReader(str(out)).pages) == 1


def test_clearance_form_builds(tmp_path, conn):
    from pypdf import PdfReader
    from sdf_app.reports.clearance_form import build_clearance_form
    rec = _rich_file(conn)
    contrib.upsert_contribution(conn, rec["beneficiary_id"], 2026, 1, 200000, user_id=1)
    bal = contrib.balance_before_file(conn, rec["beneficiary_id"], 2026, rec["file_number"])
    out = tmp_path / "clear.pdf"
    build_clearance_form(rec, bal, out)
    assert out.exists()
    assert len(PdfReader(str(out)).pages) >= 1


def test_disbursement_statement_builds(tmp_path, conn):
    from sdf_app.reports.disbursement_report import build_disbursement_statement
    rec = _rich_file(conn)
    out = tmp_path / "stmt.pdf"
    build_disbursement_statement([rec], out)
    assert out.exists() and out.stat().st_size > 1000


def test_dashboard_report_builds(tmp_path, conn):
    from sdf_app.reports.dashboard_report import build_dashboard_pdf
    fs = FileService(conn)
    _make_file(conn, 771, funding_amount=1000)
    out = tmp_path / "dash.pdf"
    build_dashboard_pdf(fs.dashboard_stats(), out)
    assert out.exists() and out.stat().st_size > 1000
