# -*- coding: utf-8 -*-
"""اختبارات إصلاحات المراجعة (1–6): الصلاحيات، الفارغ مقابل الصفر، قفل الحقول المالية،
رصيد الجهات، عقود الدولار، والنسخ الاحتياطي/الاستعادة. لا تحتاج إلى PySide6."""
import hashlib
import os
import sqlite3
import zipfile
from decimal import Decimal
from pathlib import Path

import pytest

from sdf_app import config
from sdf_app.core import finance
from sdf_app.core.field_values import EMPTY_INT, spin_to_value, value_to_spin
from sdf_app.core.review_logic import suggest_approved_count
from sdf_app.core.workflow import (TRANSITION_PERMISSIONS, TRANSITIONS, next_statuses_for,
                                   required_permissions)
from sdf_app.database.connection import Database
from sdf_app.database.seeds import seed_all
from sdf_app.services import backup_service
from sdf_app.services import contribution_service as contrib
from sdf_app.services.auth_service import (PermissionDenied, create_user, has_permission,
                                           set_role_permission, set_user_permission)
from sdf_app.services.file_service import ApprovalBlocked, FileService, LockedFields


# -- أدوات مساعدة ---------------------------------------------------------------------
@pytest.fixture()
def conn(tmp_path):
    db = Database(tmp_path / "t.db")
    c = db.connect()
    seed_all(c)
    yield c
    db.close()


@pytest.fixture()
def data_dir(tmp_path):
    """يوجّه مجلد بيانات التطبيق (القاعدة/المرفقات/النسخ) إلى مجلد مؤقت."""
    old = os.environ.get("SDF_DATA_DIR")
    os.environ["SDF_DATA_DIR"] = str(tmp_path / "data")
    config.ensure_data_dirs()
    yield tmp_path / "data"
    if old is None:
        os.environ.pop("SDF_DATA_DIR", None)
    else:
        os.environ["SDF_DATA_DIR"] = old


def _file(conn, num=1, **kw):
    data = {"file_number": num, "program_name": "برنامج", "received_date": "2026-01-05"}
    data.update(kw)
    return FileService(conn).create(data, user_id=1)


def _user(conn, role):
    return create_user(conn, f"u_{role}", f"مستخدم {role}", "secret123", role, actor_id=1)


def _walk(fs, fid, codes):
    """ينقل ملفًا عبر الحالات بصلاحيات المدير (للتجهيز فقط)."""
    for code in codes:
        fs.change_status(fid, code, user_id=1, force_exception=True, notes="تجهيز اختبار")


_TO_READY_APPROVE = ("received", "tech_review", "tech_done", "finance_review", "ready_approve")
_COMPLETE = dict(approved_trainees=10, approved_cost_per_trainee=1000, approved_hours=20,
                 funding_amount=10000)


def _ready_to_approve(conn, num=10, complete=True):
    fs = FileService(conn)
    fid = _file(conn, num, **(_COMPLETE if complete else {}))
    _walk(fs, fid, _TO_READY_APPROVE)
    return fs, fid


def _beneficiary(conn, name="جهة"):
    return conn.execute("INSERT INTO entities (name, kind) VALUES (?, 'beneficiary')",
                        (name,)).lastrowid


def _audit_rows(conn, like):
    return [dict(r) for r in conn.execute(
        "SELECT action, details FROM audit_log WHERE action LIKE ? ORDER BY id", (like,))]


# =========================================================================================
# 1) الصلاحيات
# =========================================================================================
def test_every_transition_has_explicit_permission_rule():
    assert set(TRANSITIONS) == set(TRANSITION_PERMISSIONS)
    assert required_permissions("ready_approve", "approved") == ("finance.approve",)


def test_next_statuses_for_follows_permissions():
    viewer = lambda p: p == "file.view"
    finance_user = lambda p: p in {"review.financial", "finance.approve"}
    assert next_statuses_for("ready_approve", viewer) == []
    assert "approved" in next_statuses_for("ready_approve", finance_user)
    assert "tech_review" not in next_statuses_for("received", finance_user)


def test_viewer_cannot_change_status_but_data_entry_can_receive(conn):
    fs = FileService(conn)
    fid = _file(conn, 1)
    with pytest.raises(PermissionDenied):
        fs.change_status(fid, "received", user_id=_user(conn, "viewer"))
    assert fs.get(fid)["status_code"] == "new"
    fs.change_status(fid, "received", user_id=_user(conn, "data_entry"))
    assert fs.get(fid)["status_code"] == "received"


def test_only_finance_approver_can_approve(conn):
    fs, fid = _ready_to_approve(conn)
    for role in ("data_entry", "tech_reviewer", "viewer"):
        with pytest.raises(PermissionDenied):
            fs.change_status(fid, "approved", user_id=_user(conn, role))
    assert fs.get(fid)["status_code"] == "ready_approve"
    fs.change_status(fid, "approved", user_id=_user(conn, "finance_reviewer"))
    assert fs.get(fid)["status_code"] == "approved"


def test_documented_exception_needs_reason_and_permission(conn):
    fs, fid = _ready_to_approve(conn, complete=False)
    finance_id = _user(conn, "finance_reviewer")
    with pytest.raises(ApprovalBlocked) as blocked:
        fs.change_status(fid, "approved", user_id=finance_id)
    assert any("مبلغ التمويل" in b for b in blocked.value.blockers)
    with pytest.raises(ValueError, match="السبب"):  # بلا سبب مكتوب
        fs.change_status(fid, "approved", user_id=finance_id, force_exception=True)
    with pytest.raises(PermissionDenied):  # بلا صلاحية الاعتماد
        fs.change_status(fid, "approved", user_id=_user(conn, "data_entry"),
                         force_exception=True, notes="سبب")
    res = fs.change_status(fid, "approved", user_id=finance_id, force_exception=True,
                           notes="قرار الإدارة")
    assert res["overridden"] is True and fs.get(fid)["status_code"] == "approved"
    assert len(_audit_rows(conn, "status.exception")) == 1
    assert any("[استثناء موثق]" in (h["notes"] or "") for h in fs.history(fid))


def test_attachment_permissions_and_no_overwrite(conn, data_dir, tmp_path):
    fs = FileService(conn)
    fid = _file(conn, 1)
    src = tmp_path / "a.txt"
    src.write_text("one", encoding="utf-8")
    viewer, clerk = _user(conn, "viewer"), _user(conn, "data_entry")
    with pytest.raises(PermissionDenied):
        fs.add_attachment(fid, src, user_id=viewer)
    first = fs.add_attachment(fid, src, user_id=clerk)
    src.write_text("two", encoding="utf-8")
    fs.add_attachment(fid, src, user_id=clerk)  # الاسم نفسه: يجب ألا يستبدل الأول
    names = [r["stored_name"] for r in conn.execute(
        "SELECT stored_name FROM attachments WHERE file_id=? ORDER BY id", (fid,))]
    assert len(set(names)) == 2
    folder = config.attachments_dir() / str(fid)
    assert (folder / names[0]).read_text(encoding="utf-8") == "one"
    with pytest.raises(PermissionDenied):
        fs.delete_attachment(fid, first, user_id=viewer)
    assert fs.delete_attachment(fid, first, user_id=clerk) is True
    assert (folder / names[1]).exists() and not (folder / names[0]).exists()


def test_admin_cannot_lock_self_out(conn):
    for perm in ("settings.manage", "user.manage", "backup"):
        with pytest.raises(ValueError):
            set_role_permission(conn, "admin", perm, False, actor_id=1)
    with pytest.raises(ValueError):
        set_user_permission(conn, 1, "settings.manage", False, actor_id=1)
    # صف حجب قديم (من قاعدة سابقة) لا يُفقد المدير صلاحياته المحمية
    conn.execute("INSERT INTO role_permissions (role, permission, allowed)"
                 " VALUES ('admin', 'user.manage', 0)")
    conn.commit()
    assert has_permission({"id": 1, "role": "admin"}, "user.manage", conn) is True
    # بقية الصلاحيات ما زالت قابلة للتقييد لبقية الأدوار
    set_role_permission(conn, "data_entry", "file.update", False, actor_id=1)
    assert has_permission({"id": 99, "role": "data_entry"}, "file.update", conn) is False


# =========================================================================================
# 2) الفارغ ≠ صفر
# =========================================================================================
def test_empty_spin_value_is_null_and_real_zero_is_kept():
    assert spin_to_value(EMPTY_INT) is None
    assert spin_to_value(0) == 0 and spin_to_value(7) == 7
    assert value_to_spin(None) == EMPTY_INT and value_to_spin("") == EMPTY_INT
    assert value_to_spin(0) == 0 and value_to_spin("12") == 12 and value_to_spin(5.0) == 5
    assert value_to_spin("abc") == EMPTY_INT


def test_suggested_count_treats_missing_differently_from_zero():
    missing = suggest_approved_count(contract=30, nominees=28, attendance=None, certificates=None)
    assert missing["value"] == 28  # المفقود يُتجاهل
    zero = suggest_approved_count(contract=30, nominees=28, attendance=0, certificates=0)
    assert zero["value"] == 0      # الصفر الحقيقي يبقى صفرًا (ولهذا لا يجوز حفظ الفارغ صفرًا)


# =========================================================================================
# 3) update() لا يتجاوز مسار العمل، والحقول المالية مقفلة بعد الاعتماد
# =========================================================================================
def test_update_cannot_change_status(conn):
    fs = FileService(conn)
    fid = _file(conn, 1)
    disbursed = conn.execute("SELECT id FROM file_statuses WHERE code='disbursed'").fetchone()[0]
    with pytest.raises(ValueError, match="حالة"):
        fs.update(fid, {"status_id": disbursed}, user_id=1)
    assert fs.get(fid)["status_code"] == "new"
    same = fs.get(fid)["status_id"]
    fs.update(fid, {"status_id": same, "notes": "ملاحظة"}, user_id=1)  # القيمة نفسها ليست تغييرًا
    assert fs.get(fid)["notes"] == "ملاحظة"


def test_financial_fields_locked_after_approval(conn):
    fs, fid = _ready_to_approve(conn, 20)
    fs.change_status(fid, "approved", user_id=1)
    # حفظ النموذج كاملًا بقيم لم تتغير لا يُعدّ تعديلًا مقفلًا
    fs.update(fid, {"funding_amount": 10000.0, "approved_trainees": 10, "approved_hours": 20,
                    "approved_cost_per_trainee": 1000.0, "notes": "تحديث ملاحظة"}, user_id=1)
    with pytest.raises(LockedFields) as locked:
        fs.update(fid, {"funding_amount": 99999}, user_id=1)
    assert locked.value.fields == ["funding_amount"]
    with pytest.raises(ValueError, match="السبب"):
        fs.update(fid, {"funding_amount": 99999}, user_id=1, allow_locked=True)
    with pytest.raises(PermissionDenied):
        fs.update(fid, {"funding_amount": 99999}, user_id=_user(conn, "data_entry"),
                  allow_locked=True, reason="تصحيح")
    assert fs.get(fid)["funding_amount"] == 10000
    fs.update(fid, {"funding_amount": 9000}, user_id=1, allow_locked=True, reason="خطأ في التمويل")
    assert fs.get(fid)["funding_amount"] == 9000
    detail = _audit_rows(conn, "finance.update")[-1]["details"]
    assert "10000" in detail and "9000" in detail and "خطأ في التمويل" in detail


def test_finance_audit_records_old_and_new_and_only_on_real_change(conn):
    fs = FileService(conn)
    fid = _file(conn, 1, funding_amount=1000)
    base = len(_audit_rows(conn, "finance.update"))
    fs.update(fid, {"funding_amount": 1000, "notes": "x"}, user_id=1)  # لا تغيير مالي
    assert len(_audit_rows(conn, "finance.update")) == base
    fs.update(fid, {"funding_amount": 2000}, user_id=1)
    rows = _audit_rows(conn, "finance.update")
    assert len(rows) == base + 1
    assert "1000" in rows[-1]["details"] and "2000" in rows[-1]["details"]


def test_files_before_approval_stay_editable(conn):
    fs = FileService(conn)
    fid = _file(conn, 1, funding_amount=1000)
    fs.update(fid, {"funding_amount": 5000}, user_id=1)  # قبل الاعتماد: لا قفل
    assert fs.get(fid)["funding_amount"] == 5000


# =========================================================================================
# 4) رصيد الجهات
# =========================================================================================
def test_rate_change_is_not_retroactive(conn):
    e = _beneficiary(conn)
    for m in (1, 2, 3):
        contrib.upsert_contribution(conn, e, 2026, m, 1000, user_id=1)
    contrib.set_rate(conn, 0.6, "2026-07-01", user_id=1)
    for m in (7, 8, 9):
        contrib.upsert_contribution(conn, e, 2026, m, 1000, user_id=1)
    bal = contrib.entity_balance(conn, e, 2026)
    assert bal["training_balance"] == pytest.approx(3300)  # 3×500 + 3×600
    assert bal["rate"] == 0.6                              # السارية آخر السنة
    assert bal["effective_rate"] == pytest.approx(0.55)
    contrib.upsert_contribution(conn, e, 2025, 12, 1000, user_id=1)
    assert contrib.entity_balance(conn, e, 2025)["training_balance"] == pytest.approx(500)


def test_rejected_files_do_not_consume_balance(conn):
    e = _beneficiary(conn)
    fs = FileService(conn)
    kw = dict(beneficiary_id=e, exec_start="2026-03-01")
    _file(conn, 1, funding_amount=1000, **kw)
    gone = _file(conn, 2, funding_amount=5000, **kw)
    assert contrib.funding_used(conn, e, 2026) == 6000
    fs.change_status(gone, "rejected", user_id=1)
    assert contrib.funding_used(conn, e, 2026) == 1000
    fs.change_status(gone, "archived", user_id=1)  # مؤرشف بعد الرفض: لا يزال لا يُحتسب
    assert contrib.funding_used(conn, e, 2026) == 1000
    kept = _file(conn, 3, funding_amount=700, approved_trainees=1, approved_cost_per_trainee=1,
                 approved_hours=1, **kw)
    _walk(fs, kept, _TO_READY_APPROVE + ("approved", "archived"))  # مؤرشف بعد الاعتماد: يُحتسب
    assert contrib.funding_used(conn, e, 2026) == 1700
    before = contrib.balance_before_file(conn, e, 2026, 10)
    assert before["used_before_file"] == 1700 and before["entity_year_serial"] == 3


def test_contributions_are_audited_with_old_and_new_values(conn):
    e = _beneficiary(conn)
    contrib.upsert_contribution(conn, e, 2026, 1, 1000, user_id=1)
    contrib.upsert_contribution(conn, e, 2026, 1, 1000, notes="ملاحظة", user_id=1)  # مبلغ ثابت
    contrib.upsert_contribution(conn, e, 2026, 1, 1500, user_id=1)
    contrib.upsert_contribution(conn, e, 2026, 1, None, user_id=1)
    contrib.upsert_contribution(conn, e, 2026, 2, None, user_id=1)  # حذف غير موجود: بلا قيد
    rows = _audit_rows(conn, "contrib.%")
    assert [r["action"] for r in rows] == ["contrib.create", "contrib.update", "contrib.delete"]
    assert "1,000.00 ← 1,500.00" in rows[1]["details"]


def test_contribution_and_rate_validation(conn):
    e = _beneficiary(conn)
    for bad in (-5, "abc", float("nan")):
        with pytest.raises(ValueError):
            contrib.upsert_contribution(conn, e, 2026, 3, bad, user_id=1)
    with pytest.raises(ValueError):
        contrib.upsert_contribution(conn, e, 2026, 13, 100, user_id=1)
    with pytest.raises(ValueError, match="تاريخ"):
        contrib.set_rate(conn, 0.5, "ليس تاريخًا", user_id=1)


# =========================================================================================
# 5) عقود الدولار
# =========================================================================================
_USD = {"contract_trainees": 20, "contract_cost_per_trainee": 500, "contract_hours": 20,
        "cost_currency": "USD", "exchange_rate": 2500}


def test_usd_contract_is_converted_to_riyals():
    s = finance.summarize(_USD)
    assert s["contract_cost_per_trainee_yer"] == Decimal(1250000)
    assert s["contract_total"] == Decimal(25000000)
    assert s["contract_hour_cost"] == Decimal(62500)
    assert s["contract_rate_missing"] is False


def test_usd_without_exchange_rate_is_unknown_not_dollars_as_riyals():
    for rate in (None, 0, ""):
        s = finance.summarize({**_USD, "exchange_rate": rate})
        assert s["contract_total"] is None and s["contract_hour_cost"] is None
        assert s["contract_rate_missing"] is True


def test_riyal_contract_unchanged_whatever_the_currency_field():
    for cur in ("YER", None, ""):
        s = finance.summarize({"contract_trainees": 10, "contract_cost_per_trainee": 70000,
                               "contract_hours": 20, "cost_currency": cur})
        assert s["contract_total"] == Decimal(700000) and s["contract_hour_cost"] == Decimal(3500)
        assert s["contract_rate_missing"] is False


def test_file_record_and_export_carry_converted_totals(conn):
    from sdf_app.services.export_service import EXPORT_COLUMNS, enrich_row
    fid = _file(conn, 1, contract_trainees=10, contract_cost_per_trainee=100, contract_hours=10,
                cost_currency="USD", exchange_rate=2000)
    rec = FileService(conn).get(fid)
    assert rec["contract_total"] == Decimal(2000000)
    assert enrich_row(dict(rec))["contract_hour_cost"] == Decimal(20000)
    keys = [c[0] for c in EXPORT_COLUMNS]
    assert "cost_currency" in keys and "exchange_rate" in keys


def test_review_form_cost_cell_shows_dollars_with_riyal_equivalent():
    from sdf_app.reports.review_form import contract_cost_cell
    usd = {"contract_cost_per_trainee": 500, "cost_currency": "USD",
           "contract_cost_per_trainee_yer": Decimal(1250000)}
    text = contract_cost_cell(usd, "ر.ي")
    assert "$" in text and "500.00" in text and "1,250,000.00" in text
    no_rate = {"contract_cost_per_trainee": 500, "cost_currency": "USD",
               "contract_cost_per_trainee_yer": None}
    text = contract_cost_cell(no_rate, "ر.ي")
    assert "$" in text and "1,250,000" not in text
    assert contract_cost_cell({"contract_cost_per_trainee": 700, "cost_currency": "YER"},
                              "ر.ي").startswith("700.00")
    assert contract_cost_cell({}, "ر.ي") == "—"


def test_contract_cost_text_helper():
    assert finance.contract_cost_text({"contract_cost_per_trainee": 70000}) == "70,000.00 ر.ي"
    assert "$" in finance.contract_cost_text(_USD) and "1,250,000.00 ر.ي" in finance.contract_cost_text(_USD)
    assert "غير مُدخل" in finance.contract_cost_text({**_USD, "exchange_rate": None})


# =========================================================================================
# 6) النسخ الاحتياطي والاستعادة
# =========================================================================================
class _Cursor:
    def __init__(self, rows):
        self._rows = rows

    def fetchall(self):
        return self._rows


class _FakeConn:
    def __init__(self, rows):
        self._rows = rows

    def execute(self, sql):
        return _Cursor(self._rows)


def test_quick_check_result_is_actually_read():
    assert backup_service._integrity_ok(_FakeConn([("ok",)])) is True
    damaged = [("*** in database main ***",), ("Page 3: btreeInitPage() returns error code 11",)]
    assert backup_service._integrity_ok(_FakeConn(damaged)) is False


def _backup_zip(tmp_path, name, extra=()):
    src = tmp_path / f"{name}.db"
    db = Database(src)
    c = db.connect()
    seed_all(c)
    c.commit()
    db.close()
    zp = tmp_path / f"{name}.zip"
    with zipfile.ZipFile(zp, "w") as z:
        z.write(src, "sdf.db")
        for member, content in extra:
            z.writestr(member, content)
    return zp


def test_restore_rejects_unsafe_paths_and_changes_nothing(tmp_path, data_dir):
    live = Database(config.db_path())
    c = live.connect()
    seed_all(c)
    _file(c, 1)
    live.close()
    before = hashlib.sha256(config.db_path().read_bytes()).hexdigest()
    for i, evil in enumerate(("attachments/../../zipslip.txt", "attachments/../../../zipslip.txt",
                              "../zipslip.txt", "/abs/zipslip.txt", "C:/zipslip.txt")):
        zp = _backup_zip(tmp_path, f"evil{i}", [(evil, "x")])
        with pytest.raises(ValueError, match="غير آمن"):
            backup_service.restore_backup(zp, confirm=True)
    assert not (tmp_path / "zipslip.txt").exists()
    assert hashlib.sha256(config.db_path().read_bytes()).hexdigest() == before
    # أرشيف سليم بمرفق عادي يُستعاد داخل مجلد المرفقات
    good = _backup_zip(tmp_path, "good", [("attachments/7/doc.txt", "ok")])
    backup_service.restore_backup(good, confirm=True)
    assert (config.attachments_dir() / "7" / "doc.txt").read_text() == "ok"


def test_restore_closes_live_db_clears_wal_and_audits(tmp_path, data_dir):
    live = Database(config.db_path())
    c = live.connect()
    seed_all(c)
    _file(c, 1)
    zp = backup_service.create_backup(c)  # يحوي الملف 1 فقط
    _file(c, 2)                           # تغيير لاحق (ما زال في WAL)
    backup_service.restore_backup(zp, confirm=True, database=live,
                                  actor={"id": 1, "username": "admin"})
    assert live.is_open is False
    assert not Path(str(config.db_path()) + "-wal").exists()
    assert not Path(str(config.db_path()) + "-shm").exists()
    again = Database(config.db_path())
    c2 = again.connect()
    assert [r[0] for r in c2.execute("SELECT file_number FROM training_files")] == [1]
    assert len(_audit_rows(c2, "backup.restore")) == 1
    again.close()


def _make_old_db(path):
    """قاعدة بمخطط قديم (الإصدار 2) كما في اختبار الترحيل."""
    db = Database(path)
    c = db.connect()
    c.execute("DELETE FROM schema_migrations WHERE version=3")
    c.execute("DELETE FROM schema_migrations WHERE version=4")
    c.execute("ALTER TABLE training_files DROP COLUMN clearance_number")
    c.execute("DROP TABLE IF EXISTS contributions")
    c.execute("DROP TABLE IF EXISTS programs")
    c.commit()
    c.close()


def test_pre_migration_backup_only_for_existing_old_db(tmp_path):
    # قاعدة جديدة: لا نسخة
    (tmp_path / "fresh").mkdir()
    Database(tmp_path / "fresh" / "f.db").connect().close()
    assert not list((tmp_path / "fresh").glob("backups/pre_migration_*"))
    # قاعدة قديمة: نسخة صالحة بحالتها قبل الترقية
    (tmp_path / "old").mkdir()
    p = tmp_path / "old" / "o.db"
    _make_old_db(p)
    Database(p).connect().close()
    copies = list((tmp_path / "old").glob("backups/pre_migration_v2_*.db"))
    assert len(copies) == 1 and backup_service.verify_backup(copies[0])
    snap = sqlite3.connect(str(copies[0]))
    assert snap.execute("SELECT MAX(version) FROM schema_migrations").fetchone()[0] == 2
    assert "clearance_number" not in {r[1] for r in snap.execute("PRAGMA table_info(training_files)")}
    snap.close()
    # فتح قاعدة محدَّثة مرة أخرى: لا نسخة جديدة
    Database(p).connect().close()
    assert len(list((tmp_path / "old").glob("backups/pre_migration_*"))) == 1


def test_pre_migration_backups_are_pruned(tmp_path):
    p = tmp_path / "o.db"
    _make_old_db(p)
    folder = tmp_path / "backups"
    folder.mkdir()
    for i in range(7):
        f = folder / f"pre_migration_v1_2020010{i}_000000.db"
        f.write_bytes(b"x")
        os.utime(f, (1_600_000_000 + i, 1_600_000_000 + i))
    Database(p).connect().close()
    assert len(list(folder.glob("pre_migration_*.db"))) == 5


def test_two_backups_in_the_same_second_do_not_overwrite(conn, data_dir):
    first = backup_service.create_backup(conn)
    _file(conn, 1)
    second = backup_service.create_backup(conn, notes="تلقائية")
    assert first != second and first.exists() and second.exists()
    with zipfile.ZipFile(first) as z:
        z.extract("sdf.db", data_dir / "peek")
    peek = sqlite3.connect(str(data_dir / "peek" / "sdf.db"))
    assert peek.execute("SELECT COUNT(*) FROM training_files").fetchone()[0] == 0  # الأولى بقيت كما هي
    peek.close()
